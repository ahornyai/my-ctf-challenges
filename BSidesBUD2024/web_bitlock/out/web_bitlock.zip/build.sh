#!/bin/sh

cargo build -r
cp target/release/bitlock_app .